<?php
include 'conexao.php';

$id = $_GET['id'];
$nivel = $_GET['nivel'];

if ($nivel == 1 || $nivel == 2 || $nivel == 3) {
    $update = "UPDATE usuarios SET status = 'Ativo', nivel_usuario = $nivel WHERE id_usuario = $id";
    $atualiza = mysqli_query($conexao, $update);
    if ($atualiza) {
        echo "<div class='container' style='widith: 500px; margin-top: 30px;'>
                <center>
                    <h4>";
        if ($nivel == 1) {
            echo "Administrador";
        } elseif ($nivel == 2) {
            echo "Funcionário";
        } elseif ($nivel == 3) {
            echo "Conferente";
        }
        echo " aprovado com sucesso!</h4>
                </center>
                <div style='padding-top: 20px;'>
                    <center>
                        <a href='aprovar_usuario.php' role='button' class='btn btn-primary btn-sm'>Voltar para a lista</a>
                    </center>
                </div>
            </div>";
    } else {
        echo "Erro ao aprovar usuário: " . mysqli_error($conexao);
    }
} else {
    echo "Nível de acesso inválido.";
}
?>
