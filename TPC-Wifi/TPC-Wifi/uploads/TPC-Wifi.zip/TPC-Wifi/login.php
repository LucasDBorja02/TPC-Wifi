<?php
session_start();

// Verificar se o formulário de login foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar se o nome de usuário e a senha correspondem às credenciais desejadas
    if ($_POST['usuario'] == "Lucas Borja" && $_POST['senha'] == "0504") {
        // Simular a consulta ao banco de dados para verificar o nível de administrador e o status ativo
        $nivel_admin = 1; // Nível de administrador
        $status_ativo = "Ativo"; // Status ativo
        
        // Verificar se o usuário é um administrador e está ativo
        if ($nivel_admin == 1 && $status_ativo == "Ativo") {
            // Definir a variável de sessão para indicar que o usuário está logado
            $_SESSION['usuario'] = $_POST['usuario'];
            
            // Redirecionar para a página de menu após o login bem-sucedido
            header("Location: index.php");
            exit(); // Certifique-se de encerrar o script após o redirecionamento
        } else {
            // Se o usuário não for um administrador ou não estiver ativo, exibir uma mensagem de erro
            $erro = "Você não tem permissão para acessar este sistema ou sua conta está inativa.";
        }
    } else {
        // Se as credenciais estiverem incorretas, exibir uma mensagem de erro
        $erro = "Credenciais inválidas. Por favor, tente novamente.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            width: 300px;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-top: 0;
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #007bff;
        }

        button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        .alert {
            padding: 10px;
            margin-bottom: 20px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Login</h2>
        <?php if (isset($erro)) : ?>
            <div class="alert"><?php echo $erro; ?></div>
        <?php endif; ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="usuario">Nome de Usuário:</label>
                <input type="text" id="usuario" name="usuario" required>
            </div>
            <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>
</body>

</html>

