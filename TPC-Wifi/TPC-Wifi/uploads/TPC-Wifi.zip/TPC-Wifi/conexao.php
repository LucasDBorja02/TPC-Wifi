<?php 
$servername = "localhost";
$database = "ping";
$username = "root";
$password = "";

$conexao = mysqli_connect($servername, $username, $password, $database);

// Verifica a conexão
if (!$conexao) {
    die("Conexão falhou: " . mysqli_connect_error());
}
?>
